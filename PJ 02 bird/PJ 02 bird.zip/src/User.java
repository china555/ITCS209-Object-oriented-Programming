// Name:Piyakorn Suwannakarn
// Student ID:6188110
// Section: 2

public class User {
	public int uid;
	
	public User(int _id){
		
		// YOUR CODE GOES HERE
		this.uid = _id;
	}
	
	public int getID(){
		
		// YOUR CODE GOES HERE
		
		return this.uid;
	}

}
