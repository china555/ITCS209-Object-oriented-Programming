// Name:Nattawipa Saetae
// Student ID:6188089
// Section:1

public class User {
	public int uid;
	
	public User(int _id){     
		
		// YOUR CODE GOES HERE
		uid = _id;        //set value for attributes
		
	}
	
	public int getID(){
		
		// YOUR CODE GOES HERE
		return uid;       //return id
	}

}
