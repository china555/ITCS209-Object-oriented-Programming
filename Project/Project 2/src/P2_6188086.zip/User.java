// Name:Kittikorn	
// Student ID:6188086
// Section: 1

public class User { //class Uid for user give rating each movie
	public int uid;
	
	public User(int _id) {
		
		// YOUR CODE GOES HERE
		this.uid = _id;			//set to attribute
	}
	
	public int getID(){
		
		// YOUR CODE GOES HERE
		return this.uid; //get id value
	}

}
